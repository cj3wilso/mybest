$(document).ready(function(){	
	$('.bxslider').bxSlider({
	  pagerCustom: '#bx-pager'
	});
});